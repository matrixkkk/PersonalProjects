//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Bitmap.rc
//
#define IDB_BITMAP1                     101
#define IDB_BITMAP2                     102
#define IDR_MENU1                       103
#define IDB_BITMAP3                     104
#define IDB_BITMAP4                     105
#define ID_MENU1                        40001
#define ID_MENU2                        40002
#define ID_LEVEL1                       40003
#define ID_LEVEL2                       40004
#define ID_LEVEL3                       40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
